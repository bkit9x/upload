<?php if (!defined('ACCESS')) die('Not access'); ?>

        </div>
        <div id="footer">
            <span>File Manager Version 1.0 By DucVuPro</span>
        </div>
    </body>
</html>
<?php ob_end_flush(); ?>