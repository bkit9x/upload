<?php if (!defined('ACCESS')) die('Not access'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="vi">
    <head>
        <title><?php echo $title; ?> - File Manager V1.0 By DucVuPro</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="ducvupro.css" media="all,handheld" />
        <link rel="stylesheet" type="text/css" href="style.css" media="all,handheld" />
        <link rel="icon" type="image/png" href="icon/favicon.png">
        <link rel="icon" type="image/x-icon" href="icon/favicon.ico" />
        <link rel="shortcut icon" type="image/x-icon" href="icon/favicon.ico" />
    </head>
    <body>
        <div id="header">
            <ul><li style="float:left"><b style="color:#fff">GIAITRI321.INFO                              </b></li>
                <li><a href="index.php" title="home"><img src="icon/home.png"/></a></li>
                <?php if (isset($_SESSION[SESS])) { ?><li><a href="setting.php" title="Cài Đặt"><img src="icon/setting.png"/></a></li><?php } ?>
                <?php if (isset($_SESSION[SESS])) { ?><li><a href="exit.php" title="Đăng Xuất" onclick="return dangxuat();"><img src="icon/exit.png"/></a></li>
<script>
        function dangxuat(){
            if(confirm("Đăng Xuất\nBạn Có Chắc Chắn Muốn Đăng Xuất ?") == true){
return true; }else{
 return false;
            }
        }
    </script><?php } ?>
            </ul>
        </div>
        <div id="container">
